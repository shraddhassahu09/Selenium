package Assignment;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Automation{
	public static void main(String[] args){

		  WebDriverManager.chromedriver().setup();
		  WebDriver driver=new ChromeDriver();
		  String URL="http://automationpractice.com/index.php";
	
		  driver.get(URL);
		  driver.manage().window().maximize();
		  driver.manage().timeouts().implicitlyWait(3000, TimeUnit.MILLISECONDS);

		  driver.findElement(By.linkText("Sign in")).click();
		  driver.findElement(By.id("email")).sendKeys("shraddha@test.com");
		  driver.findElement(By.id("passwd")).sendKeys("Hogwarts");
		  driver.findElement(By.id("SubmitLogin")).click();
		  Thread.sleep(5000); 
		  
		  Actions action = new Actions(driver);
		  WebElement women = driver.findElement(By.xpath("//header/div[3]/div[1]/div[1]/div[6]/ul[1]/li[1]/a[1]"));
		  action.moveToElement("WOMEN").perform();
		  Thread.sleep(1000);
		  
		  driver.findElement(By.linkText("T-SHIRTS")).click();

		  WebElement SecondImg=driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[3]/div[2]/ul/li[2]/div/div[1]/div/a[1]/img"));
		  WebElement MoreBtn=driver.findElement(By.xpath("/html/body[1]/div[1]/div[2]/div[1]/div[3]/div[2]/ul/li[2]/div[1]/div[2]/div[2]/a[2]"));
		  Actions actions=new Actions(driver);
		  actions.moveToElement(SecondImg).moveToElement(MoreBtn).click().perform();
		  
		  driver.findElement(By.id("quantity_wanted")).clear();
		  driver.findElement(By.id("quantity_wanted")).sendKeys("2");

		  WebElement Sizedrpdwn=driver.findElement(By.xpath("//*[@id='group_1']"));
		  Select oSelect=new Select(Sizedrpdwn);
		  oSelect.selectByVisibleText("L");

		  driver.findElement(By.id("color_15")).click();

		  driver.findElement(By.xpath("//p[@id='add_to_cart']//span[.='Add to cart']")).click();

		  driver.findElement(By.xpath("/html//div[@id='layer_cart']//a[@title='Proceed to checkout']/span")).click();
		  
		  driver.close();
		    
		  driver.quit();
	}
}